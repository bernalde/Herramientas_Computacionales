David Bernal
200921359
Tarea 3 Herramientas computacionales

Intrucciones para abrir los documentos presentes en esta carpeta.

Para correr el primer punto ejecutar en la terminal el archivo DavidBernal-HW3-1.sh. Este archivo generará los archivos .tx y .pdf solicitados en el punto 1.

Para generar el archivo .pdf del segundo punto, escribir en la terminal directamente "pdflatex DavidBernal-HW3-2.tex" dado que la imágen es .jpg y general un error al intentar compilarlo antes con el comando "latex DavidBernal-HW3-2.tex".

Para correr el tercer archivo en primer lugar ejecutar "latex DavidBernal-HW3-3.tex", luego el comando "bibtex referencias.aux" y finalmente el comando "pdflatex DavidBernal-HW3-3.tex".
